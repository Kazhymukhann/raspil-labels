#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор бирок для пильного центра.

Что делает:
  - тянет данные детали из базы (Google Sheet, вкладка BASE) по названию;
  - берёт ДИНАМИЧЕСКУЮ ячейку из колонки «Место» (A3, B6, E3, X ...);
  - рисует бирку 1:1 с оригиналом (QR + название + №ячейки + материал + размеры + CNC);
  - сохраняет в формате labelN.emf (две копии монохромного BMP 1419x884, как у станка).

Меняешь «Место» в таблице -> перегенерировал -> на бирке новая ячейка.

Использование:
  # ПОЛНАЯ ДИНАМИКА ИЗ ТАБЛИЦЫ (вкладка РАСПИЛ): сам соберёт все бирки задания
  python3 generate_labels.py --job 08.12.2025      # все детали за дату
  python3 generate_labels.py --job all             # всё задание целиком

  # Ручной режим
  python3 generate_labels.py "ANT-Bok L/R;27"               # деталь;кол-во
  python3 generate_labels.py --date 08.12.2025 "ANT-Bok L/R;27" "V-Bok L/R;36"
  python3 generate_labels.py --offline --job 08.12.2025     # без интернета (из кэша)

Данные: РАСПИЛ -> какие детали, сколько штук, дата;  BASE -> материал, МЕСТО, размеры, CNC.
"""

import sys, os, csv, io, json, re, urllib.request, urllib.parse

from PIL import Image, ImageDraw, ImageFont

# ---------------------------------------------------------------- настройки
HERE = os.path.dirname(os.path.abspath(__file__))

def _load_dotenv():
    """Подхватить ключи/настройки из файла .env (рядом со скриптом).
    Уже заданные переменные окружения (напр. на GitHub) имеют приоритет."""
    path = os.path.join(HERE, ".env")
    if not os.path.exists(path):
        return
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

_load_dotenv()

def norm_part_name(name):
    """Ключ для сопоставления имён из XML/РАСПИЛ/BASE."""
    s = str(name or "").strip().replace("\u00a0", " ")
    s = s.replace("/", "-").replace("Х", "x").replace("х", "x")
    s = re.sub(r"\s+", " ", s)
    return s.casefold()

def compact_part_name(name):
    """Более терпимый ключ: L-R/L_R/L R и GYF2110/GYF 2110 считаем одним именем."""
    s = norm_part_name(name).replace("_", "-")
    return re.sub(r"[\s\-_/«»]+", "", s)

def part_lookup_keys(name):
    return [norm_part_name(name), compact_part_name(name)]

def build_part_lookup(base):
    """Нормализованный lookup: имя детали -> поля BASE."""
    out = {}
    for k, v in base.items():
        for key in part_lookup_keys(k):
            out.setdefault(key, v)
    return out

def find_part(base_lookup, name, material=""):
    """Найти деталь в BASE с учётом безопасных вариантов написания."""
    variants = [str(name or "").strip()]
    mat = str(material or "").casefold()
    if "вотан" in mat:
        variants += [variants[0] + " Вотан", variants[0] + " Votan"]
    # BAZIS иногда добавляет к столешницам материал в имя папки:
    # ST-3000 Votan-Столешница _Дуб Вотан_ -> ST-3000 Votan
    cleaned = re.sub(r"\s*-?\s*столешница.*$", "", variants[0], flags=re.I)
    if cleaned != variants[0]:
        variants.append(cleaned)

    for variant in variants:
        for key in part_lookup_keys(variant):
            part = base_lookup.get(key)
            if part:
                return part
    return None

def load_sheet_id():
    """ID Google-таблицы. Берётся из env RASPIL_SHEET_ID или из config.json
    (config.json не хранится в репозитории — впиши свой ID, см. config.example.json)."""
    sid = os.environ.get("RASPIL_SHEET_ID")
    if sid:
        return sid.strip()
    cfg = os.path.join(HERE, "config.json")
    if os.path.exists(cfg):
        try:
            return (json.load(open(cfg, encoding="utf-8")).get("sheet_id") or "").strip()
        except Exception:
            pass
    return ""

SHEET_ID = load_sheet_id()           # таблица с заданием (вкладка РАСПИЛ)
RASPIL_SHEET = "РАСПИЛ"
# Детали (материал/место/размеры/кромка) — таблица Details List, вкладка Main
BASE_SHEET_ID = "1pWEjfyh_MOm1U0zPpNIyp9DkqTk6ICcxS4W-8YqzKuI"
BASE_GID = "1918355371"
CACHE = os.path.join(HERE, "base_cache.csv")
OUT_DIR = os.path.join(HERE, "labels")
ICON_PRISADKA = os.path.join(HERE, "assets", "cnc_prisadka.png")

# Канва бирки (как в оригинале со станка)
W, H = 1419, 884

# Короткие названия материалов для бирки (DB -> бирка). Дополняй по мере надобности.
MATERIAL_DISPLAY = {
    "ЛДСП Белый Молет": "ЛДСП «Белый»",
    "ЛДСП Бежевый":     "ЛДСП «Бежевый»",
    "ЛДСП Серый":       "ЛДСП «Серый»",
    "ЛДСП Белый":       "ЛДСП «Белый»",
}

FONT_DIRS = [
    "/System/Library/Fonts/Supplemental/",          # macOS
    "/usr/share/fonts/truetype/msttcorefonts/",      # Linux: Arial из msttcorefonts
    "/usr/share/fonts/truetype/liberation/",         # Linux: Liberation (метрики Arial)
]
FONT_ALIASES = {
    "Arial.ttf":       ["Arial.ttf", "arial.ttf", "LiberationSans-Regular.ttf", "DejaVuSans.ttf"],
    "Arial Bold.ttf":  ["Arial Bold.ttf", "Arial_Bold.ttf", "arialbd.ttf", "LiberationSans-Bold.ttf", "DejaVuSans-Bold.ttf"],
    "Arial Black.ttf": ["Arial Black.ttf", "Arial_Black.ttf", "ariblk.ttf", "LiberationSans-Bold.ttf", "DejaVuSans-Bold.ttf"],
}
def font(name, size):
    for d in FONT_DIRS:
        for fn in FONT_ALIASES.get(name, [name]):
            p = os.path.join(d, fn)
            if os.path.exists(p):
                return ImageFont.truetype(p, size)
    for fn in FONT_ALIASES.get(name, [name]):           # пусть PIL поищет сам
        try:
            return ImageFont.truetype(fn, size)
        except Exception:
            pass
    return ImageFont.load_default()

# ---------------------------------------------------------------- база (DB)
def fetch_base(offline=False):
    """Возвращает dict: имя детали -> словарь полей из BASE."""
    if offline and os.path.exists(CACHE):
        text = open(CACHE, encoding="utf-8").read()
    else:
        url = ("https://docs.google.com/spreadsheets/d/%s/gviz/tq"
               "?tqx=out:csv&gid=%s" % (BASE_SHEET_ID, BASE_GID))
        text = urllib.request.urlopen(url, timeout=30).read().decode("utf-8")
        open(CACHE, "w", encoding="utf-8").write(text)  # кэш на случай оффлайна

    rows = list(csv.reader(io.StringIO(text)))
    header = rows[0]
    idx = {name: i for i, name in enumerate(header)}
    def col(r, name):
        i = idx.get(name)
        return r[i].strip() if i is not None and i < len(r) else ""
    def coln(r, name):                       # None, если колонки нет
        i = idx.get(name)
        if i is None:
            return None
        return r[i].strip() if i < len(r) else ""

    base = {}
    for r in rows[1:]:
        if not r or not r[0].strip():
            continue
        name = r[0].strip()
        base[name] = {
            "name":     name,
            "material": col(r, "Материал"),
            "cell":     col(r, "Место"),       # <-- ДИНАМИЧЕСКАЯ ЯЧЕЙКА
            "prisadka": col(r, "Присадка"),
            "length":   col(r, "Длина"),
            "width":    col(r, "Ширина"),
            "thick":    col(r, "Толщина"),
            "tolk":     coln(r, "ТолК"),       # толщина кромки (0.8 жирная / 0.4 тонкая)
            "dk":       coln(r, "ДК"),         # длина-кромка: кол-во линий
            "shk":      coln(r, "ШК"),         # ширина-кромка: кол-во линий
            "date":     "",                    # уровень задания (вход)
            "qty":      "",                    # уровень задания (вход)
        }
    return base


def parse_xml(path):
    """XML раскроя (BAZIS) -> (folder, count, material).
    folder — имя папки из code «labels\\folder\\labelN»; count — число бирок (label1..labelN).
    """
    import re
    import xml.etree.ElementTree as ET
    root = ET.parse(path).getroot()
    folder, material, labelset = None, "", set()
    for el in root.iter():
        if not material and el.get("material"):
            material = el.get("material").strip()
        code = (el.get("code") or "").strip()
        if "label" not in code.lower():
            continue
        comps = re.split(r"[\\/]", code)
        if len(comps) >= 2:
            folder = comps[-2]
        m = re.search(r"(label\d+)", comps[-1], re.I)
        if m:
            labelset.add(m.group(1).lower())
    return folder, len(labelset), material


def parse_label_ref(text):
    """Строка Д1/Д2/... вида «Имя-12шт | A1» -> {name, qty}."""
    m = re.match(r"\s*(.+?)\s*-\s*(\d+)\s*шт\b", str(text or ""), re.U | re.I)
    if not m:
        return None
    return {"name": m.group(1).strip(), "qty": int(m.group(2))}


def norm_date(s):
    """08.12.2025/8.12.2025 -> 8.12.2025 для сравнения дат из таблицы."""
    s = (s or "").strip()
    p = re.split(r"[.\-/]", s)
    return ".".join(str(int(x)) for x in p) if len(p) == 3 and all(
        x.strip().isdigit() for x in p) else s


def fetch_csv(sheet, cache_name):
    """Скачать вкладку как CSV (живьём по имени) + кэш."""
    cache = os.path.join(HERE, cache_name)
    try:
        url = ("https://docs.google.com/spreadsheets/d/%s/gviz/tq"
               "?tqx=out:csv&sheet=%s" % (SHEET_ID, urllib.parse.quote(sheet)))
        text = urllib.request.urlopen(url, timeout=30).read().decode("utf-8")
        open(cache, "w", encoding="utf-8").write(text)
    except Exception:
        text = open(cache, encoding="utf-8").read()
    return list(csv.reader(io.StringIO(text)))


def parse_job_rows(date_filter=None, offline=False):
    """Читает РАСПИЛ построчно, сохраняя группу Д1/Д2/Д3... одной XML-задачи."""
    if offline:
        rows = list(csv.reader(io.StringIO(open(os.path.join(HERE, "raspil_cache.csv"),
                                                encoding="utf-8").read())))
    else:
        rows = fetch_csv(RASPIL_SHEET, "raspil_cache.csv")

    header = rows[0]
    date_i = header.index("Дата") if "Дата" in header else 0           # A
    name_i = header.index("Наименование") if "Наименование" in header else 1  # B
    qty_i = header.index("кол-во") if "кол-во" in header else 2         # C (запас)
    detail_cols = [i for i, h in enumerate(header) if re.match(r"Д\d+$", str(h or "").strip(), re.U | re.I)]
    want = norm_date(date_filter) if date_filter and date_filter != "all" else None

    out = []
    for r in rows[1:]:
        if not r or len(r) <= name_i:
            continue
        rdate = r[date_i].strip() if date_i < len(r) else ""
        if not rdate:
            continue
        if want and norm_date(rdate) != want:
            continue
        name = r[name_i].strip()
        if not name:
            continue
        refs = []
        for i in detail_cols:
            if i < len(r):
                ref = parse_label_ref(r[i])
                if ref:
                    refs.append(ref)

        # Старые/ручные строки без Д1 оставляем читаемыми, но синхронизация считает
        # корректным источником именно Д-колонки.
        if not refs:
            digits = re.sub(r"[^\d]", "", r[qty_i]) if qty_i < len(r) else ""
            if digits:
                refs.append({"name": name, "qty": int(digits)})

        if refs:
            out.append({"date": rdate, "name": name, "refs": refs})
    return out


def parse_job(date_filter=None, offline=False):
    """Читает вкладку РАСПИЛ: Д1/Д2/Д3/... дают имя детали и кол-во в партии.

    Возвращает список {name, qty, date}; количество суммируется по детали за день.
    """
    order, acc = [], {}
    for row in parse_job_rows(date_filter=date_filter, offline=offline):
        rdate = row["date"]
        for ref in row["refs"]:
            key = (ref["name"], rdate)
            if key not in acc:
                acc[key] = {"name": ref["name"], "qty": 0, "date": rdate}
                order.append(key)
            acc[key]["qty"] += ref["qty"]
    return [acc[k] for k in order]

# ---------------------------------------------------------------- QR
def qr_text(part, disp_name):
    """Текст для QR: все поля бирки (читается телефоном построчно)."""
    mat = MATERIAL_DISPLAY.get(part["material"], part["material"] or "—")
    dk, shk = _num(part.get("dk")), _num(part.get("shk"))
    t = str(part.get("tolk") if part.get("tolk") is not None else "").strip()
    if not dk and not shk and not t:
        krom = "Кромка: нет"
    else:
        krom = "Кромка: Д%d/Ш%d" % (dk, shk) + (", %s" % t if t else "")
    return "\n".join([
        disp_name,
        "%s · %sшт" % (part.get("date") or "—", part.get("qty") or "—"),
        mat,
        "Место: %s" % (part["cell"] or "—"),
        "%sx%s" % (part["length"] or "—", part["width"] or "—"),
        krom,
        "CNC: %s" % ("да" if part["prisadka"] else "нет"),
    ])


def make_qr(text, box):
    """Чёткий сканируемый монохромный QR ~box пикселей (кратно модулю, без ресайза)."""
    import segno
    qr = segno.make(text, error="m")
    modules = qr.symbol_size(border=2)[0]          # модулей вместе с тихой зоной
    scale = max(1, round(box / modules))           # целочисленный масштаб
    buf = io.BytesIO()
    qr.save(buf, kind="png", scale=scale, border=2)
    buf.seek(0)
    return Image.open(buf).convert("1")            # размер = modules*scale (≈ box)

# ---------------------------------------------------------------- отрисовка
def _num(v):
    import re
    s = re.sub(r"[^\d]", "", str(v if v is not None else ""))
    return int(s) if s else 0

def _thick(v):
    try:
        return float(str(v if v is not None else "").replace(",", ".")) >= 0.6
    except ValueError:
        return False

def _edge(d, x1, x2, y_top, count, lw):
    if not count or count < 1:
        return
    gap = lw + 8
    for i in range(count):
        d.line([(x1, y_top + i * gap), (x2, y_top + i * gap)], fill=0, width=lw)

def fit_font(draw, text, name, size, max_w):
    """Подбираем размер шрифта, чтобы текст влез в max_w пикселей."""
    f = font(name, size)
    while size > 24 and draw.textlength(text, font=f) > max_w:
        size -= 4
        f = font(name, size)
    return f

def draw_label(part):
    img = Image.new("1", (W, H), 1)            # 1-bit, белый фон
    d = ImageDraw.Draw(img)
    BLACK = 0

    # --- внешняя рамка (скруглённый прямоугольник)
    d.rounded_rectangle([6, 6, W - 7, H - 7], radius=26, outline=BLACK, width=4)

    # --- вертикальный разделитель
    DIV = 626
    d.line([(DIV, 40), (DIV, H - 40)], fill=BLACK, width=4)

    # ============================ ЛЕВАЯ ЧАСТЬ ============================
    # QR (кодируем отображаемое имя: "/" -> "-")
    disp_name = part["name"].replace("/", "-")
    qr_box = 540
    qr = make_qr(qr_text(part, disp_name), qr_box)   # в QR — все поля бирки
    qx = 44 + (qr_box - qr.width) // 2          # центрируем в области QR
    qy = 40 + (qr_box - qr.height) // 2
    img.paste(qr, (qx, qy))

    # линия под QR
    d.line([(44, 612), (590, 612)], fill=BLACK, width=3)

    # размеры "Длина x Ширина" + обозначение кромки под числами
    len_str = str(part["length"] or "—"); wid_str = str(part["width"] or "—")
    dims = "%s  x  %s" % (len_str, wid_str)
    fdim = fit_font(d, dims, "Arial Black.ttf", 96, 540)
    d.text((48, 648), dims, font=fdim, fill=BLACK)
    x1b = 48 + d.textlength(len_str, font=fdim)
    x2a = 48 + d.textlength("%s  x  " % len_str, font=fdim)
    x2b = x2a + d.textlength(wid_str, font=fdim)
    if part.get("dk") is None and part.get("shk") is None:   # колонок кромки нет — как раньше
        d.line([(48, 800), (x1b, 800)], fill=BLACK, width=3)
        d.line([(x2a, 800), (x2b, 800)], fill=BLACK, width=3)
    else:
        lw = 8 if _thick(part.get("tolk")) else 3
        _edge(d, 48, x1b, 800, _num(part.get("dk")), lw)       # Длина → ДК
        _edge(d, x2a, x2b, 800, _num(part.get("shk")), lw)     # Ширина → ШК

    # ============================ ПРАВАЯ ЧАСТЬ ===========================
    RX = 660                                    # левый край правой колонки
    RXE = W - 44                                # правый край
    RW = RXE - RX

    # 1) Наименование по системе
    ftitle = fit_font(d, disp_name, "Arial Bold.ttf", 76, RW)
    d.text((RX, 48), disp_name, font=ftitle, fill=BLACK)

    # 2) Дата  |  Кол-во в партии
    flab = font("Arial Bold.ttf", 44)
    dt = part.get("date") or ""
    p = dt.split(".")
    if len(p) == 3 and all(x.isdigit() for x in p):     # дополняем до dd.mm.yyyy
        dt = "%02d.%02d.%s" % (int(p[0]), int(p[1]), p[2])
    d.text((RX, 188), "Дата: %s" % (dt or "—"), font=flab, fill=BLACK)
    d.text((RX, 252), "Кол-во в партии: %s шт" % (part.get("qty") or "—"),
           font=flab, fill=BLACK)

    # 3) Материал
    mat = MATERIAL_DISPLAY.get(part["material"], part["material"] or "—")
    fmat = fit_font(d, "Материал: " + mat, "Arial Bold.ttf", 46, RW)
    d.text((RX, 326), "Материал: " + mat, font=fmat, fill=BLACK)

    # разделительная линия
    d.line([(RX, 420), (RXE, 420)], fill=BLACK, width=3)

    # 4) МЕСТО (ячейка) — ключевое динамическое поле, крупно
    flab2 = font("Arial Bold.ttf", 60)
    d.text((RX, 470), "Место:", font=flab2, fill=BLACK)
    fcell = font("Arial Black.ttf", 104)
    lab_w = d.textlength("Место:", font=flab2)
    d.text((RX + lab_w + 28, 438), part["cell"] or "—", font=fcell, fill=BLACK)

    # 5) CNC: + иконка операции (присадка) — снизу справа
    fcnc = font("Arial Bold.ttf", 60)
    d.text((RX, 690), "CNC:", font=fcnc, fill=BLACK)
    if part["prisadka"] and os.path.exists(ICON_PRISADKA):
        icon = Image.open(ICON_PRISADKA).convert("1")
        img.paste(icon, (RX + 200, 640))

    return img

# ------------------------------------------------------- сохранение в .emf
def save_emf(img, path):
    """Сохраняем как 1-bit BMP, продублированный дважды (формат файлов станка)."""
    buf = io.BytesIO()
    img.convert("1").save(buf, format="BMP")
    bmp = buf.getvalue()
    with open(path, "wb") as f:
        f.write(bmp)
        f.write(bmp)            # вторая копия — как в оригинальных файлах

# ---------------------------------------------------------------- main
def main():
    import datetime
    args = sys.argv[1:]
    offline = "--offline" in args

    def opt(flag):
        return args[args.index(flag) + 1] if flag in args else None

    os.makedirs(OUT_DIR, exist_ok=True)

    # ---- режим XML: по раскрою BAZIS -> N одинаковых бирок в одноимённую папку ----
    if "--xml" in args:
        base = fetch_base(offline=offline)
        folder, n, material = parse_xml(opt("--xml"))
        if not folder or not n:
            print("  ! В XML не найдены бирки (label-коды)"); sys.exit(1)
        pname = folder[:-(len(material) + 1)] if material and folder.endswith("-" + material) else folder
        base_norm = build_part_lookup(base)
        part = find_part(base_norm, pname, material)
        if part is None:
            print("  ! Деталь не найдена в базе: %r (папка %r)" % (pname, folder)); sys.exit(1)
        outdir = os.path.join(OUT_DIR, folder)
        os.makedirs(outdir, exist_ok=True)
        today = datetime.date.today().strftime("%d.%m.%Y")
        img = draw_label(dict(part, date=today, qty=str(n)))
        for i in range(1, n + 1):
            save_emf(img, os.path.join(outdir, "label%d.emf" % i))
        print("  %d бирок -> %s  (деталь %s, Место %s)"
              % (n, outdir, part["name"], part["cell"] or "—"))
        return

    if not SHEET_ID and not offline:
        print("  ! Не задан ID таблицы. Создай config.json (см. config.example.json)\n"
              "    или задай: export RASPIL_SHEET_ID=<id>")
        sys.exit(1)

    base = fetch_base(offline=offline)
    base_lookup = build_part_lookup(base)

    # ---- собираем список заданий: (name, qty, date) ----
    jobs = []
    if "--job" in args:
        # ПОЛНАЯ ДИНАМИКА: тянем задание прямо из вкладки РАСПИЛ
        for j in parse_job(date_filter=opt("--job"), offline=offline):
            jobs.append((j["name"], str(j["qty"]), j["date"]))
        if not jobs:
            print("  ! За '%s' в РАСПИЛ ничего не найдено" % opt("--job"))
            sys.exit(1)
    else:
        # ручной режим: "Имя" или "Имя;кол-во", дата через --date
        job_date = opt("--date") or datetime.date.today().strftime("%d.%m.%Y")
        skip = {args.index("--date") + 1} if "--date" in args else set()
        items = [a for k, a in enumerate(args)
                 if not a.startswith("--") and k not in skip]
        if not items:
            print(__doc__)
            sys.exit(1)
        for it in items:
            name, qty = (it.rsplit(";", 1) + [""])[:2] if ";" in it else (it, "")
            jobs.append((name.strip(), qty.strip(), job_date))

    # ---- генерим бирки ----
    n = 0
    for name, qty, date in jobs:
        part = base.get(name) or find_part(base_lookup, name)
        if part is None:
            print("  ! НЕ найдено в BASE: %r — пропуск" % name)
            continue
        n += 1
        part = dict(part, date=date, qty=qty)
        img = draw_label(part)
        out = os.path.join(OUT_DIR, "label%d.emf" % n)
        save_emf(img, out)
        print("  label%d.emf  <-  %s | Место: %s | %s шт | %s | %s | %sx%s"
              % (n, part["name"], part["cell"] or "—", part["qty"] or "—",
                 part["date"], part["material"], part["length"], part["width"]))
    print("  ИТОГО бирок: %d  ->  %s" % (n, OUT_DIR))

if __name__ == "__main__":
    main()
